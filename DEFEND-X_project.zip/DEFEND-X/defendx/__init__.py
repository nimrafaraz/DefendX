"""DEFEND-X: a defensive, educational multi-domain awareness simulation (synthetic data only)."""
__version__ = "1.0"
